from django.forms import ModelForm
from .models import ChildInfo

class ChildInfoForm(ModelForm):
    class Meta:
        model = ChildInfo
        exclude = ()