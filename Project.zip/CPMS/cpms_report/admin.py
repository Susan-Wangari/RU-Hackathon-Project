from django.contrib import admin
from .models import ChildInfo


admin.site.register(ChildInfo)
