from django.shortcuts import render
from .forms import ChildInfoForm
from .models import ChildInfo
from json import dumps
from django.contrib.auth.decorators import login_required
from django.db.models import Avg, Max, Min, Sum

def dashboard(request):
    if request.method == 'GET':
        template = "dashboard.html"
        return render(request, template)
    else:
        query = request.POST['doc']
        data = ChildInfo.objects.filter(location=query)
        context = {'form':data}
    template = "sum.html"
    return render(request, template,context)


def register(request):
    if request.method == "GET":
        template = "registration.html"
        return render(request, template)
    else:
        obj = ChildInfo()
        obj.childName = request.POST['cname']
        obj.age = request.POST['ages']
        obj.gender = request.POST['gender']
        obj.location = request.POST['locations']
        obj.offense = request.POST['offenses']
        obj.reporterName = request.POST['rname']
        obj.phoneNo = request.POST['phoneNo']
        obj.idNo = request.POST['idno']
        obj.lats = request.POST['lat']
        obj.longs = request.POST['longs']
        obj.childImage = request.FILES['pic']
        obj.save()
        template = "registration.html"
        return render(request, template)

def hotSpots(request):
    lat_data1 =ChildInfo.objects.values_list('lats')
    long_data1 =ChildInfo.objects.values_list('longs')
    print(long_data1)
    lat_data = list(lat_data1)
    long_data = list(long_data1)
    
    context = {'lat_data':lat_data,'long_data':long_data }
    template = "coord.html"
    return render(request, template,context)

@login_required()
def summary(request):
    data = ChildInfo.objects.values('childName','age','gender','location','offense')
    context = {'form':data}
    template = "sum.html"
    return render(request, template,context)

def smcount(request):
    childsdata= ChildInfo.objects.values('childName').count;
    typecases = ChildInfo.objects.values('offense')
    locationcase = ChildInfo.objects.values('location')
    malenum = ChildInfo.objects.filter(gender='male').count
    femalenum = ChildInfo.objects.filter(gender='female').count
    maxage = ChildInfo.objects.all().aggregate(Max('age'))
    minage = ChildInfo.objects.all().aggregate(Min('age'))
    print(maxage)
    context = {'formc':childsdata, 'typec': typecases,
    'malec':malenum,'femc':femalenum, 'locc':locationcase, 
    'maxa':maxage, 'mina':minage}
    template = "sum.html"
    return render(request, template,context)
    

