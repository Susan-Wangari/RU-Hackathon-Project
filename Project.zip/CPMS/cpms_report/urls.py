from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name="dashboard"),
    path('register/', views.register, name="register"),
    path('coord/', views.hotSpots, name="hotSpots"),
    path('report/',views.summary, name="summary"),
    path('counts/', views.smcount, name='smcount'),
]