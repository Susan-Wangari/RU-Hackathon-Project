from django.db import models

class ChildInfo(models.Model):
    childName = models.CharField(max_length=100)
    age = models.IntegerField()
    timeSubmitted = models.DateTimeField(auto_now_add=True)
    gender = models.CharField(max_length=20)
    location = models.CharField(max_length=20)
    offense = models.CharField(max_length=220)
    reporterName = models.CharField(max_length=100)
    phoneNo = models.IntegerField()
    idNo = models.IntegerField()
    lats = models.FloatField()
    longs = models.FloatField()
    childImage = models.FileField()
    

