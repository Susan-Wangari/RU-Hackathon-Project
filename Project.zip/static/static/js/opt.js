

function getLocation() {  
        if(navigator.geolocation){  
            navigator.geolocation.getCurrentPosition(showPosition)  
          }  
        else  
        {  
             alert("Sorry! your browser is not supporting")  
         } }  
       
  function showPosition(position){  
          document.getElementById("lat").value = position.coords.latitude;
            document.getElementById("long").value = position.coords.longitude;  
     } 
     
  function drawMap() {
    var lats = document.getElementById("lats").value;
    var longs = document.getElementById("longs").value;
      geolocate = new google.maps.LatLng(lats,longs);
      console.log(lats)
      let mapProp = {
        center: geolocate,
        zoom:5,
      };
      let map=new google.maps.Map(document.getElementById('map'),mapProp);
      let infowindow = new google.maps.InfoWindow({
        map: map,
        position: geolocate,
        content:
          `Location from HTML5 Geolocation:
             <br>Latitude: ${lats}
             <br>Longitude: ${longs}`
         });
    }
    // drawMap(data,data);
    function initMap() {
      var lats = form[0][0]
      var longs = form[0][1]
      const uluru = { lat: lats, lng: longs };
      // The map, centered at Uluru
      const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 4,
        center: uluru,
      });
      // The marker, positioned at Uluru
      const marker = new google.maps.Marker({
        position: uluru,
        map: map,
      });
    }

    function initMapb(){
    var lats = document.getElementById("lats").value;
      var longs = document.getElementById("longs").value;
  mapboxgl.accessToken =  'pk.eyJ1IjoiZGVubmlzbWltaSIsImEiOiJja3A3aXF1eWMwMHBlMm5uMW1haHg1ZDAxIn0.Tq-kQCA3r1t9mSF1oRcgfA';
    var map = new mapboxgl.Map({
     container: 'map',
     style: 'mapbox://styles/mapbox/satellite-streets-v10',
     center: [longs,lats],
     zoom: 9,
     bearing: 180
    });

  }