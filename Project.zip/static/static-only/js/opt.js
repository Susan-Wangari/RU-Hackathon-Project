function askNo() {
    var num = prompt("Enter Your Mpesa No");
    var result = confirm("are you ready to pay ksh200");
    if (result == 1) {
        return num;
    } else {
        return null;
    }
}